import React from 'react';
import FirstName from './Components/FirstName';
// import LastName from './Components/LastName';
// import MiddleName from './Components/MiddleName';
import Occupation from './Components/Occupation';
import Location from './Components/Location';

const imgGirl = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAMAAzAMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcCCAH/xAA9EAABAwMCAwUFBgYBBAMAAAABAAIDBAUREiEGMUETIlFhcQcUMoGhFSNCkbHBM1Ji0eHwQ2NygvEWJDT/xAAXAQEBAQEAAAAAAAAAAAAAAAAAAgED/8QAHBEBAQACAwEBAAAAAAAAAAAAAAECERIhMUED/9oADAMBAAIRAxEAPwDtKIiAiIgJjPPkibHbxQQ3DgxJd8s0k3GXP9XLdTKhbBWxTXC70rWtbLDVkvI/FkbH6KZByMhB+oiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAg552wiFBRrZJJQ8d3Nv/HUTAPLtti0EYV5XKOOKxts461SyuYJII5GMaCS5w25fILpNquDbjRRTdm6KUt78L/iYfNG6byIOninTKMEREBE6Z6LXrqynoKOWqq5mwwRN1ve84ACDY64RaNmrftKibXNyIZ+9C0jcM6Z/VbyAiIgIiICIiAiIgIiICIiAiIgL8cQ1pJ5Bfqw1J+7wEHHfancHUnFtFW6W6jTkROcMgEO/XdZ7NXz17mup3Sl+4dOHd8+nhutH2zxhtZaKo7aJHMznHgcfRSXBf2d9nNnlh0zv7v8QknyU1fxa6K919va2CYitBdgGQ4cD69Vv/8AyeSR7RBQuaHN5yOx3vDZRjocNe4BnL4eZ9V6t9ZSCcwGZjXvOwc3rhTumm3W8U1tLRy1LLO6aOMHOiUZ2Xum4yopbAbu6MNib8bNQyD4LWoAIbzJDKSWTsPxHu7f4VUvVsktF1q6KGDVarjG4loGezfjn+a3kcV3oOMrVWax97EWAlwc3OAOuyiOKXN4ttlTTQPHuEcmWPx/Ge0ZB9AVQuEPe7dcKqBgE7n4GprvixgforJQXeohhmoXsMcsZy1gO2M8/kOaXI4rVw7fKWn4fpfewKeOGMM1DJAx1Pgp2iutur2aqKtp5x/05AV88cQ3J1xpKuOSumpKKEEUsbR/+x+rvA+AW77PqOOtmt73RgPE74nOaMEt0OPMeGAUueoyY9vobf8AlI9UK5HPxHe7aTDbbg6WNr9P37e0x+a9UPtNutvGm700NW4nB7H7sgDr4FVKyyuteqehVVt/HlgucUbKKuj96le1gppO68OPl5K0tbpY1o/CtY/UREBERAREQEREBERAWKcdwrKvMgywoOP+2SLVb6OTSDoqh9QQoXgGWaRzoWEOjMgI7m4+ZVl9rzM8OySDnFMx2fmoDgJxp4qZ5OovI7mnOPM+CnJcdOH3TD24k0YwDy2+RVX4orrfbwyokmcJA4Njbq1OcfBrevzW9XVpuNx+z6SRrNIJmdzA8uaj7jwtQ0nut7p4TO+llPvTB3nmNwwSB/TkHHhlc8rqKkRcntFppGwTm23NkNNPo96MbdOrwxn6KxtndfIoq6hcZXwscTGTh4zsQQVza98O3maqNJbZXVFpqZhK0RuBaCeuPFTVx4hlsnFFtFpYZhSQllc2Eag9riO7t1GMqectmmY7+rM2jgNw98o4zGQwFzBgeufNflPF2lyrDK4a5KV5idgb+Smo44azVV0MuGSkyNBbzyOS0LxGG0sc0A0vG7sjl0P7qmuW8O3CjuFv+xrxZqiqMchbFLTtyc9M+fzV6oLTFZaL3WGN8Er4zlhIL4Y3cyTnGo488Ba/DjZ7LUumhjbJC4v7R0TcguJ6+C3K+OomkfJC17JJvje/vavBZPzkuxFUzmxGTFNPJSYAeIzkOP8AUeZC/LpFaqO1Pmqqlz6mY914ADh4Actlmpae5va5oqm0bRlx7u2f7KBis775diyaqc9rOcx6+gVGkcWw0jtUet8xALGt+I9crs/s64nffrWYq4tZX050vHV7ejvXoqeOGaaytfLCHyd0Fznt3J8B5Kq1F3nsF7oa+lD2TCTL2Buzm9R6K8anKPohFhpKhtTTQzs+GVgeMdMhZlSBERAREQEREBERAXl/wn0XpeZPgKDmntUi7ThS5Hnhgdj0OVXeCKmD3KJjhkfofVXD2gxCXh64x4+KB65HwhXh3ZOe7swwc/RTVx0SxUT6iSeup8F3bFjgXYGByyeSzSVVwpKhxdXQwSO2axml3r6+nNQ1jL521LhM6Gknm1Md+pUw6zx1Du0+1WTxMdz2AaMdVC2ua62SjtKyghm1HvuZC6Eu35gealp5rVTWeT7Io4qSeRuCA0Z81EtpW1r4p6PMxLtOvV+AdcqdhoxTUwkrYyGganYGSs1B+WdxtraSjlZI0BoDicY1HfHyUtdGQyQ98txgkjHRebpb3XOhfUWxzJKlgJjbq2z69FzW43a9RxzW68TupJ2NOWhmCQfM7Y8wjcceVWngnsZqutpo5RMymDnOa3fYlb8U9TU1MkVCxpha4NdNIfu4/MHqtT2S2yODhiqrmxky1krm77FzWkgb+ZyVKMgw9wLWS6dQ7M7Rt67+K3fSajb7bpKeidUSSe9PDSXPawhg81G8LxQ0dN7zIWue7k4fstvjOvgNHHROmJe851MHcaPA4Ubay6OMyl8b4GNzhpUqniTvtXEymmqLgXNjGMNGx5c1yusq5brXOquzkbAx2lgLjv8ARSHENxqL9cJI2Pe2njPfc3u5HgFIWy0OpYY563VDTs7zRnmTyyFcQvHsqv8AI7NkrZMv0GSlznZo+JmfyI+a6MCD+3mvnCturoLpFPQnVUQyiRjmjABC+gLBdoL3aKa4Ursslbu3+UjmPkVcRUgiItYIiICIiAiIgJtyPJEQV3iizuq7fUhhaWGF5cHH+kr5htT2RVIjmaS0nS7vYyvrqsGaOceMbh9F8jTxBlwnY4bxTP8AnhxCytjrcFdBSWgU9NTudOQA0NGcfPksFFwvcpsSykMjk779ZwB4kqB4Sv4EbYZ5w1zXd0n64XTLfW6oGubE9/UBwJPmcrnk6yte126alxpBMTCC1xBx6kdVYY7XDJvUSy1U5GdLXYYz8v8ASteW4F2ljoQQ78GOXmVIMnxG5rsmM/gacE+ZWQsYaCFtDUOcwwxknvCNp2KjuPaW0Xi1ysr4Iy6Nh01DhhzPQj9FpXO71sILYKVkbcANyeQ8z1Wh9g1N3kbNc7g6cucCIWnDGj0TZJWrYuNIqeww08VHUmOBmhgjbpDgFH1PEt4uYmIoXUlNHuNWDjzVvbabfbhI12kgjJzyVIvd2ZM6SljlYIG/E5ZtutPVvppHydsX5afj1jUMeBH6HooniG4mpApbTqbGHbhpOt58B4rUZX1VZUe6UTndm5pY5o2OPE+Ss9HQ0XDsDJKgB1S7k7wPgAt8Z6x0FtMFugnqGjtx3zHpGlo9Op8+a1biyous7uxJLPg7SZ3TyAwPkpq3UUl4jdU3DMMTXd2Fpxqb4lSEs7YQKempmv6Ds2n/ANLds0qRggtjRFDTtDyzvyPYe96K8ex24wz2yuomu+9hn7QsycBpHTKj2UD5GF1c6WRmMCLXjA83DdYrDX03C17mqpWf/VlZ2cjo3l2nB2JyqlTY6uiw0dZT11LHU0crZoJBlkjeRWZWgREQEREBERAREQY5/wCBJ/2O/RfJnEsZpuIboxvMVTseh3/dfWkhxFIeeGH9F8t8f0oj4wuBkdojeWSADmcsHIfLmsqp4h6AGWQSA4ijILzy0n/KvNr4jraIjMpc2Nvea47tHhjq49B+HmVRpJnU0cehgZI4fdxj/jz+I+LlOWCAiDt525px8eDkud4fPH0Kykrp9s4thPYtr4TE6b4WjcgealpL5QmlDu2wHObG0+v+5+ap9hNNPKBUNjdI/uxOceQ8vDwU9VWikd2LHNDRkyhpOBuNvoo06RrXe9wGAmJ4e9x7pxzUR9t10UbnUsb2vIGgk8/FTv2bRxRj+GXNdtg/RYa2kjmjI0GOM7ah1U9NU6uut3vNWIWTOwB94ejR4eqjqynjpHmFxdPVyYYyPmcnkrTXS01oocRxtLWnbP4j4+a3uErDDVyMvE7AZRuNXQk4A+QW7DhLhn7KoPeaxzTNLh0rjtny9AtujtjrpX/aVUQ2mi/hAj4j4qdrGsrKk0wOIIRqkJOAtG63aGlptMDeY0xsaFLXiqLJXtcZuwgZudQ2etOa+wQwshoKd8zy4Boj6H1WK32Suvkglr29nCM4i5ee6tVvs9HbWgRxtHX4ckH1VJqrPZfa4PApo6eN++Xu+HHplR9Xw7W9m981YdTm/CI+Y9P7q4VlZHC12p2hobkk9c/VRtnrae8X2mpGyZeHanNB6Dc7Kp6m+L9w7b22ux0VE0AdlE0H1xupFDjO3JF0cxERAREQEREBERBiqTinlP8AQV85+1GBtNxSKqRoLTTR6Wn8TgXD8sYX0bUM7WCSPPxNwFxT2z8NztpqS8zu0NjcYC3n3TuD+Yx80VHJG6ppy5znOe8+PirtwwO3DrYMFjBqLc839T8uSqVKxlOx9V2jTp7sZLfxH+wW7w7VS0twjkZoDOTnnclZSOjRWuWjnhh7TNMCC5w+JrsqTqRVSmT3pmmlYzaVvPYFadJcDDPDUgdrTybuOPh9FPUd2tsjmNdLGGSNy9rjnfHIKKuMXDtJRGR33wqGjGCT1WtxjUTEinpGY5DVjYZK247jZ7bPmFsTHSHB3xkqF4g4kbITS0WiSSR2Q0Dr/ZYpV66Ga/XX3Gk1vho2DV4H/K63bKdlNbYWYDcNaNGeXJVX2fWSWD3uoq4+zmldy8QrvO3TEdHdONx6LL4xVL3WGmpTA1x1zPLnFgyTjkFucO8Pzzz+/XFoyfgjI+ELTjpG1V2pI5db2RNJIcdiQVfInxxQ7EtH6KdNoIGwsw0DA8lEXarjhb8bRtnmstVdmOe6OFxe7O+Oijp7cyrImqycHfQCtIplxqX3CV0NDHJK5zvi/VWH2YWQQ189a+JgMcQaw5yck75/JYLzX01uh7Gme2KYuDWxs+LJVt4HgNPZGTVBa2WqcZCDgaRyH0V4TtGXiyBFhlqoImF0krA0dcrR+3aPUR94QDjIYuunNITyNhhfK/k1uVTaq7VVTM6UPdGDya07BSt8uDamEU9KS5rt3OCh2UbtO4WyC8oiKQREQEREBQfFdpivVpqKGobqjewt+ZHNTi8vaHMcCg+RL7Svt9c+3SNIdSHRv1PMn5rSpHaXuc7fQwkDz5D6rqXtu4cNPWQ3uCPuO+6qMDkfwu/ZcoyW580a6bwJdWVNI2irHN7uzc438MKzUfBlJURNe+d/aNOzmnGADyXKuFZI23CIyEknJBPTbK6dZL5UwRaKzO/ea4Hk3z8FFi5WrXcAy6pnRTukc4EMyT3Qtjh7gmehuEdZUv1O06QDvhW6C5QODI+2w53MLfilje09/JHIZ5KFtBtS2mqGQP7rwNnBvNSDZBO4FvPzCxzQCYAta0kHOf3SMkZ1N742yFgiLhJJTXEzQtBbtqOOYyFv3KvLKfQCBlu5B2Xu4QNfSOYGbDBUNUyCSaKB7C5zSC7oGjmg3qU01DTiWslEbnHIBURcbvU3KeWmtZEcbO6ZvLxWnWUVZdKuSaumEFI06Qc4z4LDHNa6IiGGscxxADjjYea2QZ/drfZGtrKyZ9TV4OC7BOcdPBb3CF2qhbZJLjGfd3zuMRPMA7/ko5tVY6SQyVFSamU7ta8fX/K07nxQydkcVJTnDdsR7j0yqxuqm9ujRiGqjcYnBzXDmFmitzXNzgk+KonCldWW4udcO5FNuG5zp/sum26aN8QIIIIGCORXfltyuOmkLeG/hwtllvy3YKRc1ruYX7t0GFnJgiIpaIiICIiAiIgg+KrRFdrZUUkzQWTsLXZ6eB/NfK91oJbZX1FDUNIlgkLDn9fy3+a+v6iPtItON+i4r7a+FJo42X+ngLo2gMqSzfT/ACuPl0Ru3LrQ57KprmNyQCfouoWB7Z6BsM8TXvIDu7+pXJWPkiflp0kA74Vp4erJIYch8znD8TBspqovlLRVNFNrGZGjJJO+fVTtqrIJg57qjs5di9uyq1svsxjcJYZNPUgFZnQw1j2ucySHUQdWkjZQt0CGUkHMuvI8N8LK9zdLu9p9VV46KaKLtKKqc52MAP8A981mhlqZg5k7tBYcAHry/wArBLGo1sLCfmoxkUlTKMNLnPOnH7rIJe4ASCBy81KWWmAMkjw1xHw45ozb3Pb2PhELtOADqDuir1dw/bpXBzp2MlJwcYwfkp64GnlieyqkMWdtio2Oy2iSQzGVzwdiS8ghIIuPgu2y6pKiWSTB7gBwFtUvDdtoHmYRN7TOQSdm/JSzKOGPEdLMXFm4aX8wqvxRcLrSkPhic7Owa3daNbiGsiEhi1tfPjSzTyaT19VaeDq8voYYpXkyQgMfn+Yc/quXUdFXVFea2vb2Xe1HOcD0V0tVS6mriGtLA8jY/wC8/JXjWXx1aNwc0EL0tK1yOkpWuct1XXMREWAiIgIiICIiAta40FLc6SSjr4RNTSDvxucQHeuOa2UQc0469nds+xpKqw0sdHUQDU4NZqLm9QM8j6Lj1v10VVrkcXD4XaznHyX1W74TlUmv9nNguNzmqy+ZglOexhIa0HrhNNlVqxPgqIQ4xB+2zicKwwRUpYCXMDvA7qWoOCLJRNAjjnfj+aYqVhslthHcpGH1OVNxVyU+opT8cMzCRuGjooySGua7OmSQg6hpbnddNjo6ZnwQRD/xWXDRyA/LCzicnMYqG5yM+6ppc52L4+islqp5qSj1VzAJc53bpVrB5+SrV/r8VLGN7x5aVl6JdtC6VNKGvZIxznnAzpz9VUOIrRcSz3iiqZSzTns2HAA/urzTVEdRqEseDjfUFrVrIiXRMGppYQA38OFKnL+G73WWy7COpldI0nDmyEldFraykqKN0wcBrBG391zWurWU1z019NqMbtntGM+qkam6U9XRtjo5HxuOzowPLxVN0mKFtLVVOgyBzBuCDnB8h+62XxQx3J0gBe7bGf2Hh+qh+EaMxVMj+z0BvLUScqxU0TXT6m4yTv1VYzaau3D0vaUgJ543HgpZRNkj0AeYUsrrmIiLAREQEREBERAREQOf+V40MByG4PkvaIAREQEREHl7tLSc9FAxtgnnfIWBzh+IKUuhe6nMTHaS/wDF4LQggZFEY4vDc+a55XteLVqJGscA7AG4OSNlBVFK6WYup59IPJreTl44o4dluJD21z4TyeA7GdlCUdhrLbK1s93kezm0B+DhSps3Oggnjf2sEMjw3mWZ/wBKqtqtofWBkPZFxfgx5Ax5q2XEvY9rKckxuGC0u3Kx8L2ptC2aud8UhOgObyVTttbwpI6ZpYHAv64bhb9sps4OCtdre1lLnHJO6nbfCBjZdZNOdqbtzNLFuLHA3TGFkSpf/9k="

const imgBoy = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJ0AqAMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQUGAgQHAwj/xAA4EAABAwIFAgQDBgQHAAAAAAABAAIDBBEFEiExQQYTUWFxgSIykQcUobHB8BUjUtEWJDM0QuHx/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAECAwQF/8QAIBEBAAICAgIDAQAAAAAAAAAAAAECAxESITFBBBMiUf/aAAwDAQACEQMRAD8A7ehCCgEJXRdA0JXRdA0JXQSgaFjdFzwgyQvISxucWNcC5u4B2XoCmw0JJhAIQhAIQhAIQhAAoQhAiki6V0DukldF0DQldMFAIQhAb82WlilV91pLsOWR5s0+Hn9FulQeLv7te2MG4ib8QG4J/wCrLLNfjXbTFXlbTTM4p2snYfiaQT5j9/mrNG4PY1zdiFT60Oc0tDmk8X/VS+E4tD91hiqSYZGjIc+gNhwfosMWSItqZbZcczXcQnQheUU8czQ6JzXDxabj6r0uuzr05piY8mhJNEBF0kkGV0XWKaBoSuhAilymUuUCRbwTRZAtU07J2QFl4VNTHBlDmudm/obstjYKEx6ft9xwF+20m3sotOo2mI3OnvXYxBTt/lnuPtoBx6lVo4pCZJA6dncOr3A3stFzZ6i0zm2DeM5s46bjndFPUiamfBLFF3ABkc5oGYctJOy8nJltknU9Q9PHhrSu48smYpTyw1U0c8EzYQS4wuDi0j8ivJ1ZG9tpGhkrmNcG5trnb15UTgGBnCsWkr6uqb3p5HRyC5aHRkO0LTyPhOmnw6KRdAzsCa13fM0DU67LK9NT120rPtt0UstIR2H5CdT23WN7cgaFS1D1LUMhMdTEHyjRpBsCPPwVSpZ46PEGwVdTBC1kQZHTumbmc76+fqVMwXc4EixOhG6tjvkpPtF6UvG50kJ8Qqqu4fM5t9mMu0e1t/dS/S8sz21DZXuexjgG5tx4qulgYS57/haLkeSsnTBd/D7ubbuOLv3+C78XdvLiydU1pNFYovdC63KSEIQCEIQNJNLlAFCChA+FkseEiUCleGMLjqBvbdc5quoZq7HKvD3UVTSspzd8kwDc1+RrqDweVc6zHaKnfI1znOczcsbcel1VG4zhWNYm+ppX5S0CKVx+UkXtY82WOWfzptjjvbxhknxCXsuc+G1wBpc+fmsqmiNOx3ccHPtuflUw2ARu7kcl/EHn00UdV4xHTVD4KyCSZr/kfGy5Plpyuefjfjy3r8j99QqONhlLVU00jJP5pDO4+7g3yvxdS1AamLC31FPWNmmMuTxLP6j67ALVr21VfCRLTSfcg/OdQHNA14On5r1ooqWhOWhgZCHn4g1u58T4/muKKfXMTLuteL1mIaOM9FxVeL0746FjaZhcXAMu+Qnl0lzfxudTb2U4Yn4WGU752zRsAax4+a4GxsvbqSriFPTQlzQRGCQ6/wCf6qAmvA2LufJI8DKXXuLHbS3K1zcmOHjKSFQ+un7JdIGA/GLixur3hNR2qZrHWytHAsuUVWPnCccw+k+7vljqmAHt3L2m9tuQul4c7u9rtvBa65JHj6cLu+NEfXv+uL5M/vSep35wXD5SdF7jZecLA2MDlZroc4SWSSBIQhA0ikUigd0XPH4pJ+10GLZmuJZfK/exUX1JisWF4dJJJK2IEG73G2VvJW3iFLHVRmJ1wRqHNJBafZfO3XmMVWOY6+hfXTS0VK4tF3gtc65BcLb7b+Xmq2nS1Y2nKjG5+pZ3U+HB8WH3IDzo6bwJ8G+SkMDpZsLpY48rWve4572340W19n+FM+7xyOaMo2tz5q51OGQzTseBYjUC26wyUtbUw3petJmJaGF41T1sX3eoHZqG6auIBUT1CKiNpfTzNkHlo4LDqvAZH/5qlu143sqwMbqqW8WJQipi2FxZ4t531WvmNSy33uFlwfHmBroZIwzZrmmwvpr6pPe2KqDooGmK/wAAzAel/RQOG1eEV8ohbVFjy6zWvuCD6/RWqhweNoaGOa8A+qjhGtTC3Od9S3JmQ1WGPMo7kwacwHBtxyqrXVr2UkUJjfZz8oDhyPLj0VwrR26Q950bQG/MAPoVRxUNpKwVFjIGyBzm3GttfHyVM2KLel8WTjC39CdOMkqp8ZroS57m9imbIPlZu51j4n8ldafDYaZ+aIWHh5KqdP8AWlNWxtdFEDACWuLXHOwjxH7urpTzx1ELZYXBzHagtOi2pEVrpjeZtO3qABqhF0XVlDSRdJAIQhAihMpcoCyEiorHcbgwlsLpCCXyZSwnUjkoKj9tPUEGG9OuwyOpy11aWt7cZOcxf8ttr2t53XDKCJ0tTmMZIcbAafv+yvXV3SFfiuPTY1R1rcRZO/O+Jw7c0Y4GXYi22U38l4UuDZH5bNGX5g7cHwXLnycXXgxxZfejA6LDYNC0lu3CszH/ABCx1G6qfTERgY6nbK463s8882U+17ongybHS/gtcd4tVjlpNbJd1MyQAPsQfFQOKdKUlSHOyDMVPU897NduB9V7GxBIHsrs/DkOP9FvhHcpGEFpvcbj0VSqn19HXQQh07HyFxdZ3zAN5X0HNTdxpaR5KsYx0pBV4vQVQOXsF+duS4eHC2/Hr5Inr2oeHSV9e2JsgkOUWJcSb8L06gZHhmGmWckXBF/G/wD6rzUUlNhsRklyRNaLkkjZcm+0DqL+JS9mIZYGaMb4+vmqytHaAwvH6rBcSNTBctJs9gNg9t9vXz813LoDqelxExyU0toZT23x31Y/YXHjfnlfOcji438tlvYDjVZgdc2qo37fDJHf4ZByCP1Vqq28vsQHf+yFWugup6bqrAo6ymfeWM9ueNxu5jgOfG455+qMY6voqKvOGUEb8RxXQmlgNu208vdbK0e5OuysqsqFCUdZikv+5NMwnXLC12nlcn14HspGFsztZJCmhtIWIJAsmgZS5WSVkGDlQ+vun6jE2Nmgd8cdyGq+lYPjbI0tIB9VI41hlTUwEwzhwezQgqbIZXx2e3M+2h2KtuJ9PQVJMjYwJBsbLSpcNZEdBqqXpFqzEr0tqYlC9PmVmIMaxv8AKGg1urRXQtfGSBlNuFp4JRsjga8j4zqFMTMLoH3HCxxUmlWuXJyt0rcVY+klEL9WA/NypeGrLgCDmadj/datVTMeA4b2WhFM6luC7Ry1iZZTG03LWZPicNB7KKxPHY6eNzubX81D4pVPmjLRe50dqo8UclRfNf6qJlMVQHV+KVNdHZhfYm4sb3XPamjmlc5zmnQ3Oi7F/DIzsBYaWUB1DhzXEUlDA6Sqk3axpJ/BVttemvDlUzcjrEa2XnHHJNK2OCN0kjtA1rSSfYLpuFfZjPVzB+K1PajJuYYSC73dsPxXTMA6SoMJiDMPo44Qfmfa73erjqVrXqO2Vtb6ci6W+z/H6o55aiXC4JQM4DyJHt8wCAPddq6W6VocEpBDR04jB1e86vkPi53Km6OhjhIcRqt7L4DRWUYRRNjbYBelggBNEmEJBNB6LErJYlQFyknykgLaKOxGmDmPy6CVpbe/iLKRSc0PFiLjwQUvDsSGF4r9wxFwbDNYRSH5WHjXgcfRW0wNe3LqQRrr+qq/XOHMqaAvYwZ23tbhc5w7F8Qweoz0dVJE4btvdp9QdElMO0HDoS2wBHoVpVHTlNOQe7Kwg8FQOBfaJSTgRYrGaaS3+q0F0Z9tx+K2v8b0ddVmkoKaaVr2lveccnFtuVGoO4R9PSwy1MsELXuDSWBxtrYqRjw7ILFlz/SBqpjDMOho6RjY2hjso+K3Kr+I4nitFLI8vtlO5aCCPGycYNy9WdOyzSmeplEMLQSWM1dYeJ4WnRU33iQimjEcbjuG6uHBJOpU50/j1JitA9lWY2TgFkjRs8bXC38PoWQRgAWtpsnGDcvGgw9sQGnupNkYa3ZZNaALALKysggE7IQgEBMBFkDtohMBCgZFKyySQY2SsmQlZBiQgaLKyLKRpV1MKiB7DsVzbHelJmyPlhaSD4BdWsvKWna9pDmgg+KDgc1DPC/I6Nw9lbuh8JkE3dkaRc6aK8VOAU07sxY2/ot6hw6OlaAxoFvJRpO3pJE4wZW3BtoRwub9SYPiUVS+Zs0kgd5rqTWgAiy16mljmjc1wRCi9HULw9rpWWde6v8AG0Buy0KSgbTy3aLaqSaNApCsi3msrIsoGNkWWVkWQIBCdkWQFkLIBCAQhJAiiyaCgVkITCBWRZNCBWCAAmhAIIuhCBZQnZCEAiyYQgVkWTQgQTQUwgSE0IP/2Q=="

const arrPersons = [
  {
    id: 1,
    gender: 'man',
    firstName: 'Ivan',
    surname: 'Ivanov',
    patronymic: 'Иванович',
    // job: {1:'student',2:'student_2',3:'student_3'},
    job: ['student_1','student_2','student_3'],
    location: 'Moscow',
  },
  {
    id: 2,
    segenderx: 'woman',
    firstName: 'Name_2',
    surname: 'FamyliName_2',
    patronymic: 'Patronymic_2',
    job: {1:'occupation_2_1',2:'occupation_2_2',3:'occupation_2_3'},
    location: 'location_2',
  },

  {
    id: 3,
    gender: 'woman',
    firstName: 'Name_3',
    surname: 'FamyliName_3',
    patronymic: 'Patronymic_3',
    job: ['occupation_3_1','occupation_3_2','occupation_3_3'],
    location: 'location_3',
  },
  {
    id: 4,
    gender: 'man',
    firstName: 'Name_4',
    surname: 'FamyliName_4',
    patronymic: 'Patronymic_4',
    job: ['occupation_4'],
    location: 'location_4',
  },
];

function App() {
  console.log('start');

  return (
    // <div style={{ border:'…', backgroundColor: constColorThrue  ? "green" : "grey",}}
    <div>
      {/* <div style = {{backgroundColor: 'yellow'}}> */}
      {/* // <div style = {{backgroundColor: {constColorThrue}  ? "green" : "grey",}}> */}
      {arrPersons.map((el) => {
        // const constColorThrue = true
        const genderColor = el.gender === 'man' ? true : false;
        const imgOut = el.gender === 'man' ? imgBoy : imgGirl;
        // console.log(el.job)
        // console.log('el.job[]')
        // console.log(el.job['1'])
        return (
          <div
            key={el.id}
            style={{
              width: '300px',
              border: '5px solid grey',
              'border-radius': '15px',
              padding: '20px',
              margin: '10px',
              backgroundColor: genderColor ? 'blue' : 'pink',
            }}
          >
            {/* <img src={imgUrl} alt="girl"/> */}
            <img src={imgOut} alt="girl" style={{width:'100px',"border-radius":'50px',
              position: 'relative', left:'200px'
            }}/>
            <FirstName title = "Имя" titleColor = '#ccc' name={el.firstName} />
            <FirstName title = "Фамилия" titleColor = '#468'name={el.surname} />
            <FirstName title = "Отчество" titleColor = 'red' name={el.patronymic} />
      
            <Occupation job={el.job} />
            <Location city={el.location} />
          </div>
        );
      })}
    </div>
  );
}

export default App;
