import React from 'react';

const MiddleName = ({ patronymic }) => {
  return <div>Отчество: {patronymic}</div>;
};

export default MiddleName;