import React from 'react';

const FirstName = ({title, titleColor, name }) => {
  return <div>
  <div style = {{
    display: 'inline-block',
    backgroundColor: '#999',
    
    'border-radius':'5px',
    'margin-bottom':'5px',
    padding:'5px'}}>
<i style={{color:titleColor}}>{title}: </i>  {name}</div>
</div>
};

export default FirstName;