import React from 'react';

const LastName = ({ surname }) => {
  return <div>
  <div style = {{
    display: 'inline-block',
    backgroundColor: '#999',
    // 'margin-top':'5px',
    'border-radius':'5px',
    padding:'5px'}}>
<i>Фамилия:</i>  {surname}</div>
</div> 
};



export default LastName;