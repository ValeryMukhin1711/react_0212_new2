import React from 'react';

const Location = ({ city }) => {
  return <div>Место жительства: {city}</div>;
};

export default Location;