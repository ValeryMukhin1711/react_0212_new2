import React from 'react';

const Occupation = ({ job }) => {
 console.log("Occupation start")
  console.log('job',job)
  console.log('job["0"]',job['0'])
  console.log('{job}',{job})
  console.log('job[0]',job[0])
  const multyJob = job.length > 1 ? true : false
  console.log('multyJob',multyJob)
  if (multyJob) {
    const jobArray = job
    console.log('jobArray',jobArray)
    return <div>
      
      {jobArray.map((el) => {
        console.log('el',el);
        return <div><div style={{background:"#bbb", display:"inline-block", padding: '3px', color:'#753', border:"1px solid", "border-color":"red","border-radius":'5px',margin:'1px'}}>{el}</div></div>
      })}

    </div>

  }
  else {

    return <div>Род деятельности: {job['0']}</div>

  
  }


};

export default Occupation;