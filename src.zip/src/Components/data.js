export default let arrPersons = [{
  id:1,
  firstName:"Ivan",
  surname:"Ivanov",
  patronymic:"Иванович",
  job:"student",
  location:'Moscow'
}]